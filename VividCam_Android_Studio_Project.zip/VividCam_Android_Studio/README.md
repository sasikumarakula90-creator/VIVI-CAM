# VividCam — Android Studio project

A standalone CameraX app starter with a DSLR-Vivid-inspired capture pipeline:
- CameraX still capture using MAXIMIZE_QUALITY and JPEG quality 100.
- Adjustable saturation, brightness, contrast and edge sharpening.
- Saves processed JPEGs to `Pictures/VividCam`.

## Build the APK
1. Install the latest stable Android Studio on Windows/macOS/Linux.
2. Install Android SDK Platform 35 and a compatible Android SDK Build-Tools package in SDK Manager.
3. Open this folder (`VividCam_Android_Studio`) in Android Studio.
4. Allow Gradle sync to download dependencies.
5. Connect the Samsung Galaxy A07 4G, enable USB debugging, and run the `app` configuration.
6. To create an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Device compatibility
The project uses minSdk 26 and targetSdk 35. It is designed as a standalone camera app; it does not modify Samsung's stock Camera app or its image pipeline. Confirm the phone's actual Android/One UI version in Settings → About phone → Software information.

## Image-quality limitations
This app adjusts rendered JPEG pixels after capture. It cannot add sensor detail, optical zoom, or true optical bokeh, and sharpening cannot recover detail that the sensor/lens did not capture. Strong sharpening may create halos/noise; use the sharpness slider moderately. CameraX hardware capabilities and output resolution depend on the device camera implementation.

## Project notes
This is a starter implementation and has not been compiled or tested on the Galaxy A07 4G in this environment. Android SDK/Gradle build tools are required to produce and verify the APK.
