package com.sasigraphics.vividcam;

import android.Manifest;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CAMERA = 41;
    private PreviewView previewView;
    private ImageCapture imageCapture;
    private ExecutorService cameraExecutor;
    private SeekBar saturationBar, brightnessBar, contrastBar, sharpnessBar;
    private TextView status;
    private int saturation = 135; // percent
    private int brightness = 8;   // additive RGB
    private int contrast = 112;   // percent
    private int sharpness = 25;   // percent

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cameraExecutor = Executors.newSingleThreadExecutor();
        buildInterface();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) startCamera();
        else ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA);
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    private void buildInterface() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(8,11,18));
        root.setPadding(dp(14), dp(8), dp(14), dp(10));

        TextView title = text("VIVIDCAM", 22, Color.WHITE);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(42)));

        TextView subtitle = text("DSLR VIVID  •  LIVE CAMERA", 11, Color.rgb(255,181,71));
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(24)));

        previewView = new PreviewView(this);
        previewView.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        previewParams.setMargins(0, dp(8), 0, dp(10));
        root.addView(previewView, previewParams);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(dp(12), dp(8), dp(12), dp(4));
        controls.setBackgroundColor(Color.rgb(20,25,36));

        saturationBar = addSlider(controls, "SATURATION", 0, 200, saturation, "135%");
        brightnessBar = addSlider(controls, "BRIGHTNESS", -30, 30, brightness, "+8");
        contrastBar = addSlider(controls, "CONTRAST", 70, 150, contrast, "112%");
        sharpnessBar = addSlider(controls, "DETAIL / SHARPNESS", 0, 100, sharpness, "25%");

        root.addView(controls, new LinearLayout.LayoutParams(-1, dp(230)));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER);
        bottom.setPadding(0, dp(8), 0, 0);

        Button reset = new Button(this);
        reset.setText("RESET");
        reset.setOnClickListener(v -> resetControls());
        bottom.addView(reset, new LinearLayout.LayoutParams(0, dp(52), 1f));

        Button capture = new Button(this);
        capture.setText("●  TAKE PHOTO");
        capture.setTextColor(Color.BLACK);
        capture.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(255,181,71)));
        capture.setOnClickListener(v -> takePhoto());
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(52), 2f);
        cp.setMargins(dp(8), 0, 0, 0);
        bottom.addView(capture, cp);
        root.addView(bottom);

        status = text("Photos save to Pictures/VividCam", 10, Color.LTGRAY);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, dp(24)));
        setContentView(root);
    }

    private SeekBar addSlider(LinearLayout parent, String label, int min, int max, int initial, String valueText) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(label, 10, Color.WHITE);
        name.setTypeface(null, 1);
        row.addView(name, new LinearLayout.LayoutParams(dp(142), dp(24)));
        TextView value = text(valueText, 10, Color.rgb(255,181,71));
        value.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        row.addView(value, new LinearLayout.LayoutParams(0, dp(24), 1f));
        parent.addView(row);

        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(initial - min);
        parent.addView(bar, new LinearLayout.LayoutParams(-1, dp(28)));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int val = progress + min;
                if (bar == saturationBar) saturation = val;
                else if (bar == brightnessBar) brightness = val;
                else if (bar == contrastBar) contrast = val;
                else if (bar == sharpnessBar) sharpness = val;
                value.setText((val > 0 && min < 0 ? "+" : "") + val + (bar == saturationBar || bar == contrastBar ? "%" : ""));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        return bar;
    }

    private void resetControls() {
        saturationBar.setProgress(135);
        brightnessBar.setProgress(38);
        contrastBar.setProgress(42);
        sharpnessBar.setProgress(25);
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider provider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                imageCapture = new ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                        .setJpegQuality(100)
                        .build();
                provider.unbindAll();
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture);
                status.setText("DSLR Vivid profile ready");
            } catch (Exception e) {
                status.setText("Camera could not start: " + e.getMessage());
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void takePhoto() {
        if (imageCapture == null) {
            Toast.makeText(this, "Camera is starting. Please wait.", Toast.LENGTH_SHORT).show();
            return;
        }
        status.setText("Processing full-resolution photo…");
        imageCapture.takePicture(cameraExecutor, new ImageCapture.OnImageCapturedCallback() {
            @Override public void onCaptureSuccess(@NonNull androidx.camera.core.ImageProxy image) {
                try {
                    ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                    byte[] bytes = new byte[buffer.remaining()];
                    buffer.get(bytes);
                    int rotation = image.getImageInfo().getRotationDegrees();
                    image.close();
                    Bitmap source = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    if (source == null) throw new IllegalStateException("Could not decode photo");
                    Bitmap processed = enhance(source, saturation / 100f, brightness, contrast / 100f, sharpness / 100f);
                    savePhoto(processed);
                    if (processed != source) source.recycle();
                    processed.recycle();
                    runOnUiThread(() -> {
                        status.setText("Saved to Pictures/VividCam");
                        Toast.makeText(MainActivity.this, "Vivid photo saved", Toast.LENGTH_SHORT).show();
                    });
                } catch (Exception e) {
                    image.close();
                    runOnUiThread(() -> {
                        status.setText("Photo processing failed");
                        Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                    });
                }
            }
            @Override public void onError(@NonNull ImageCaptureException error) {
                runOnUiThread(() -> status.setText("Capture failed: " + error.getMessage()));
            }
        });
    }

    private Bitmap enhance(Bitmap input, float sat, int bright, float contrastValue, float sharp) {
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(sat);
        float c = contrastValue;
        float t = 128f * (1f - c) + bright;
        ColorMatrix tone = new ColorMatrix(new float[]{
                c,0,0,0,t, 0,c,0,0,t, 0,0,c,0,t, 0,0,0,1,0
        });
        cm.postConcat(tone);
        Bitmap output = Bitmap.createBitmap(input.getWidth(), input.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawBitmap(input, 0, 0, paint);
        if (sharp > 0.01f) {
            Bitmap sharpened = sharpen(output, sharp);
            output.recycle();
            return sharpened;
        }
        return output;
    }

    private Bitmap sharpen(Bitmap src, float amount) {
        int w = src.getWidth(), h = src.getHeight();
        int[] pixels = new int[w * h];
        int[] out = new int[w * h];
        src.getPixels(pixels, 0, w, 0, 0, w, h);
        float center = 1f + 4f * amount;
        for (int y = 1; y < h - 1; y++) {
            for (int x = 1; x < w - 1; x++) {
                int i = y * w + x;
                int a = pixels[i], n = pixels[i-w], s = pixels[i+w], e = pixels[i+1], west = pixels[i-1];
                int r = channel(a,16,n,16,s,16,e,16,west,16,center,amount);
                int g = channel(a,8,n,8,s,8,e,8,west,8,center,amount);
                int b = channel(a,0,n,0,s,0,e,0,west,0,center,amount);
                out[i] = Color.argb(Color.alpha(a), r, g, b);
            }
        }
        // Preserve border pixels.
        for (int x=0; x<w; x++) { out[x]=pixels[x]; out[(h-1)*w+x]=pixels[(h-1)*w+x]; }
        for (int y=0; y<h; y++) { out[y*w]=pixels[y*w]; out[y*w+w-1]=pixels[y*w+w-1]; }
        Bitmap result = Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        result.setPixels(out,0,w,0,0,w,h);
        return result;
    }

    private int channel(int a,int ashift,int n,int nshift,int s,int sshift,int e,int eshift,int west,int wshift,float center,float amount) {
        float v = ((a >> ashift)&255)*center
                - ((n >> nshift)&255)*amount
                - ((s >> sshift)&255)*amount
                - ((e >> eshift)&255)*amount
                - ((west >> wshift)&255)*amount;
        return Math.max(0, Math.min(255, Math.round(v)));
    }

    private void savePhoto(Bitmap bitmap) throws Exception {
        String filename = "VividCam_" + System.currentTimeMillis() + ".jpg";
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
        if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/VividCam");
        Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IllegalStateException("Could not create image file");
        try (OutputStream stream = getContentResolver().openOutputStream(uri)) {
            if (stream == null || !bitmap.compress(Bitmap.CompressFormat.JPEG, 98, stream))
                throw new IllegalStateException("Could not save image");
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_CAMERA && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startCamera();
        else Toast.makeText(this, "Camera permission is required", Toast.LENGTH_LONG).show();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (cameraExecutor != null) cameraExecutor.shutdown();
    }
}
